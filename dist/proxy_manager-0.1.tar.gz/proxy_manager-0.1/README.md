### proxy_manager

Модуль для получения актуальных прокси по своей апи. 

Использование: 
Сохраняем в папке `/home/user/dev/modules/proxy_manager`

Устанавливаем
```bash
pip install /home/user/dev/modules/proxy_manager
```

Подключаем 
```python
from proxy_manager import ProxyManager
```

Пример использования: 
```python
proxies = ProxyManager(token)
proxies.get() # Возвращает список актульных прокси
```            